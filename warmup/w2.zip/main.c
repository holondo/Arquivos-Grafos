#include <stdio.h>
#include <stdlib.h>
#include "record.h"

int main(int argc, char const *argv[])
{
    char fname[100] = "regi.dat";//file name
    int opt = 0;

    FILE *data = NULL;
    if ( (data = fopen(fname, "w+") ) == NULL)
        puts("Error while opening file.");

    csv2bin(data);
    print_interval(data, records_quantity(data) - 10, records_quantity(data) - 1);

    fclose(data);
    return 0;
}